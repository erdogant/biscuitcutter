import os
import sys

def get_user_inputs():
    """Ask the user for the required template replacements."""
    print("=== Project Template Initializer ===")

    github_name = input("1. GITHUBNAME (e.g., lskywalker): ").strip()
    if not github_name:
        print("Error: GITHUBNAME cannot be empty. Exiting.")
        sys.exit(1)

    repo_name = input("2. REPONAME (e.g., okenobi): ").strip()
    if not repo_name:
        print("Error: REPONAME cannot be empty. Exiting.")
        sys.exit(1)

    author_name = input("3. AUTHORNAME (e.g., Luke Skywalker): ").strip()
    if not author_name:
        print("Error: AUTHORNAME cannot be empty. Exiting.")
        sys.exit(1)

    contact_email = input("4. CONTACTADRESS (e.g., luke@tosche-station.net): ").strip()
    if not contact_email:
        print("Error: CONTACTADRESS cannot be empty. Exiting.")
        sys.exit(1)

    return {
        "GITHUBNAME": github_name,
        "REPONAME": repo_name,
        "AUTHORNAME": author_name,
        "CONTACTADRESS": contact_email
    }

def replace_in_files(root_dir, replacements):
    """Recursively string replace placeholders in all text files."""
    script_name = os.path.basename(__file__)

    for subdir, dirs, files in os.walk(root_dir):
        # Ignore common version control and environment directories exactly
        # .github/workflows IS processed because it is not in this ignore list.
        dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', 'venv', '.venv']]

        for file in files:
            # Prevent the script from modifying itself or the lock file
            if file in [script_name, '.biscuit']:
                continue

            filepath = os.path.join(subdir, file)

            try:
                # Read file contents
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Perform replacements
                new_content = content
                for key, value in replacements.items():
                    new_content = new_content.replace(key, value)

                # Write back if changes were made
                if new_content != content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(new_content)
                    print(f"Updated content in: {filepath}")

            except UnicodeDecodeError:
                # Skip binary files that can't be decoded as UTF-8
                pass

def rename_files_and_directories(root_dir, repo_name):
    """Recursively rename files and directories containing 'REPONAME'."""
    script_name = os.path.basename(__file__)

    # Walk bottom-up (topdown=False) to ensure we rename children before their parent directories.
    for subdir, dirs, files in os.walk(root_dir, topdown=False):

        # Split the path into its individual folders.
        # This safely ignores '.git' while fully allowing '.github' and '.github/workflows'
        path_parts = subdir.split(os.sep)
        if '.git' in path_parts:
            continue

        # 1. Rename Files
        for file in files:
            if file == script_name:
                continue

            if 'REPONAME' in file:
                old_path = os.path.join(subdir, file)
                new_name = file.replace('REPONAME', repo_name)
                new_path = os.path.join(subdir, new_name)
                os.rename(old_path, new_path)
                print(f"Renamed file: {old_path} -> {new_path}")

        # 2. Rename Directories
        for d in dirs:
            if 'REPONAME' in d:
                old_path = os.path.join(subdir, d)
                new_name = d.replace('REPONAME', repo_name)
                new_path = os.path.join(subdir, new_name)
                os.rename(old_path, new_path)
                print(f"Renamed directory: {old_path} -> {new_path}")

def main():
    target_directory = os.path.dirname(os.path.abspath(__file__))
    lock_file = os.path.join(target_directory, '.biscuit')

    # --- Safety Check: Has this run before? ---
    if os.path.exists(lock_file):
        print("\n⚠️  WARNING: The biscuit is already created!")
        print("To redo, redownload the repo and start all over again.\n")
        sys.exit(0)

    # 1. Get dictionary mapping placeholders to user input
    replacements = get_user_inputs()

    print("\n--- Starting Content Replacement ---")
    replace_in_files(target_directory, replacements)

    print("\n--- Starting File & Directory Renaming ---")
    rename_files_and_directories(target_directory, replacements["REPONAME"])

    # --- Drop the biscuit ---
    with open(lock_file, 'w') as f:
        f.write("This repo has been initialized. Do not run the init script again.")

    print("\n✅ Project initialization complete! The biscuit has been baked.")

if __name__ == "__main__":
    main()
