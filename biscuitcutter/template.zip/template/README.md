[![Python](https://img.shields.io/pypi/pyversions/REPONAME)](https://img.shields.io/pypi/pyversions/REPONAME)
[![Pypi](https://img.shields.io/pypi/v/REPONAME)](https://pypi.org/project/REPONAME/)
[![Docs](https://img.shields.io/badge/Sphinx-Docs-Green)](https://GITHUBNAME.github.io/REPONAME/)
[![LOC](https://sloc.xyz/github/GITHUBNAME/REPONAME/?category=code)](https://github.com/GITHUBNAME/REPONAME/)
[![Downloads](https://static.pepy.tech/personalized-badge/REPONAME?period=month&units=international_system&left_color=grey&right_color=brightgreen&left_text=PyPI%20downloads/month)](https://pepy.tech/project/REPONAME)
[![Downloads](https://static.pepy.tech/personalized-badge/REPONAME?period=total&units=international_system&left_color=grey&right_color=brightgreen&left_text=Downloads)](https://pepy.tech/project/REPONAME)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](https://github.com/GITHUBNAME/REPONAME/blob/master/LICENSE)
[![Forks](https://img.shields.io/github/forks/GITHUBNAME/REPONAME.svg)](https://github.com/GITHUBNAME/REPONAME/network)
[![Issues](https://img.shields.io/github/issues/GITHUBNAME/REPONAME.svg)](https://github.com/GITHUBNAME/REPONAME/issues)
[![Project Status](http://www.repostatus.org/badges/latest/active.svg)](http://www.repostatus.org/#active)
[![DOI](https://zenodo.org/badge/231843440.svg)](https://zenodo.org/badge/latestdoi/231843440)
[![Medium](https://img.shields.io/badge/Medium-Blog-black)](https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html#medium-blog)
[![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html#colab-notebook)
[![Donate](https://img.shields.io/badge/Support%20this%20project-grey.svg?logo=github%20sponsors)](https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html#)

<div>
<a href="https://GITHUBNAME.github.io/REPONAME/">
  <img src="https://raw.githubusercontent.com/GITHUBNAME/REPONAME/master/docs/figs/logo.png"
       width="250"
       align="left" />
</a>
REPONAME is a Python package for probability density fitting of univariate distributions for random variables.
The REPONAME library can determine the best fit for over 90 theoretical distributions. The goodness-of-fit test is used to score for the best fit and after finding the best-fitted theoretical distribution, the loc, scale, and arg parameters are returned.
It can be used for parametric, non-parametric, and discrete distributions. ⭐️Star it if you like it⭐️
</div>

---

### Key Features

| Feature | Description |
|--------|-------------|
| [**Parametric Fitting**](https://GITHUBNAME.github.io/REPONAME/pages/html/Parametric.html) | Fit distributions on empirical data X. |
| [**Non-Parametric Fitting**](https://GITHUBNAME.github.io/REPONAME/pages/html/Quantile.html) | Fit distributions on empirical data X using non-parametric approaches (quantile, percentiles). |
| [**Discrete Fitting**](https://GITHUBNAME.github.io/REPONAME/pages/html/Discrete.html) | Fit distributions on empirical data X using binomial distribution. |
| [**Predict**](https://GITHUBNAME.github.io/REPONAME/pages/html/Functions.html#module-REPONAME.REPONAME.REPONAME.predict) | Compute probabilities for response variables y. |
| [**Synthetic Data**](https://GITHUBNAME.github.io/REPONAME/pages/html/Generate.html) |  Generate synthetic data. |
| [**Plots**](https://GITHUBNAME.github.io/REPONAME/pages/html/Plots.html) | Varoius plotting functionalities. |

---

### Resources and Links
- **Example Notebooks:** [Examples](https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html)
- **Blog Posts:** [Medium](https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html#medium-blog)
- **Documentation:** [Website](https://GITHUBNAME.github.io/REPONAME)
- **Bug Reports and Feature Requests:** [GitHub Issues](https://github.com/GITHUBNAME/REPONAME/issues)

---

### Background

* For the parametric approach, The REPONAME library can determine the best fit across 89 theoretical distributions.
  To score the fit, one of the scoring statistics for the good-of-fitness test can be used used, such as RSS/SSE, Wasserstein,
  Kolmogorov-Smirnov (KS), or Energy. After finding the best-fitted theoretical distribution, the loc, scale,
  and arg parameters are returned, such as mean and standard deviation for normal distribution.

* For the non-parametric approach, the REPONAME library contains two methods, the quantile and percentile method.
  Both methods assume that the data does not follow a specific probability distribution. In the case of the quantile method,
  the quantiles of the data are modeled whereas for the percentile method, the percentiles are modeled.

---

### Installation

##### Install REPONAME from PyPI
```bash
pip install REPONAME
```

##### Install from Github source
```bash
pip install git+https://github.com/GITHUBNAME/REPONAME
```

##### Imort Library
```python
import REPONAME
print(REPONAME.__version__)

# Import library
from REPONAME import REPONAME
```

<hr>

### Examples

##### [Example: Quick start to find best fit for your input data](https://GITHUBNAME.github.io/REPONAME/pages/html/Examples.html#)

```python

# [REPONAME] >INFO> fit
# [REPONAME] >INFO> transform
# [REPONAME] >INFO> [norm      ] [0.00 sec] [RSS: 0.00108326] [loc=-0.048 scale=1.997]
# [REPONAME] >INFO> [expon     ] [0.00 sec] [RSS: 0.404237] [loc=-6.897 scale=6.849]
# [REPONAME] >INFO> [pareto    ] [0.00 sec] [RSS: 0.404237] [loc=-536870918.897 scale=536870912.000]
# [REPONAME] >INFO> [dweibull  ] [0.06 sec] [RSS: 0.0115552] [loc=-0.031 scale=1.722]
# [REPONAME] >INFO> [t         ] [0.59 sec] [RSS: 0.00108349] [loc=-0.048 scale=1.997]
# [REPONAME] >INFO> [genextreme] [0.17 sec] [RSS: 0.00300806] [loc=-0.806 scale=1.979]
# [REPONAME] >INFO> [gamma     ] [0.05 sec] [RSS: 0.00108459] [loc=-1862.903 scale=0.002]
# [REPONAME] >INFO> [lognorm   ] [0.32 sec] [RSS: 0.00121597] [loc=-110.597 scale=110.530]
# [REPONAME] >INFO> [beta      ] [0.10 sec] [RSS: 0.00105629] [loc=-16.364 scale=32.869]
# [REPONAME] >INFO> [uniform   ] [0.00 sec] [RSS: 0.287339] [loc=-6.897 scale=14.437]
# [REPONAME] >INFO> [loggamma  ] [0.12 sec] [RSS: 0.00109042] [loc=-370.746 scale=55.722]
# [REPONAME] >INFO> Compute confidence intervals [parametric]
# [REPONAME] >INFO> Compute significance for 9 samples.
# [REPONAME] >INFO> Multiple test correction method applied: [fdr_bh].
# [REPONAME] >INFO> Create PDF plot for the parametric method.
# [REPONAME] >INFO> Mark 5 significant regions
# [REPONAME] >INFO> Estimated distribution: beta [loc:-16.364265, scale:32.868811]
```

<p align="left">
  <a href="https://GITHUBNAME.github.io/REPONAME/pages/html/Examples.html#make-predictions">
  <img src="https://github.com/GITHUBNAME/REPONAME/blob/master/docs/figs/example_figP4c.png" width="450" />
  </a>
</p>


#

##### [Example: Plot summary of the tested distributions](https://GITHUBNAME.github.io/REPONAME/pages/html/Examples.html#plot-rss)

After we have a fitted model, we can make some predictions using the theoretical distributions.
After making some predictions, we can plot again but now the predictions are automatically included.

<p align="left">
  <a href="https://GITHUBNAME.github.io/REPONAME/pages/html/Examples.html#plot-rss">
  <img src="https://github.com/GITHUBNAME/REPONAME/blob/master/docs/figs/fig1_summary.png" width="450" />
  </a>
</p>

#

<hr>

### Contributors
Setting up and maintaining bnlearn has been possible thanks to users and contributors. Thanks to:

<p align="left">
  <a href="https://github.com/GITHUBNAME/REPONAME/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=GITHUBNAME/REPONAME" />
  </a>
</p>

### Maintainer
* AUTHORNAME, github: [GITHUBNAME](https://github.com/GITHUBNAME)
* Contributions are welcome.
* Yes! This library is entirely **free** but it runs on coffee! :) Feel free to support with a <a href="https://GITHUBNAME.github.io/donate/?currency=USD&amount=5">Coffee</a>.

[![Buy me a coffee](https://img.buymeacoffee.com/button-api/?text=Buy+me+a+coffee&emoji=&slug=GITHUBNAME&button_colour=FFDD00&font_colour=000000&font_family=Cookie&outline_colour=000000&coffee_colour=ffffff)](https://www.buymeacoffee.com/GITHUBNAME)
