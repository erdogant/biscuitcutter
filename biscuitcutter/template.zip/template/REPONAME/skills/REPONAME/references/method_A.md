# Method / Function

## Overview

<!-- Briefly describe what this method or function does and when to use it. -->

## Signature

```python
# REPONAME.my_function(...)
```

## Parameters

| Parameter | Type   | Default   | Description                   |
| --------- | ------ | --------- | ----------------------------- |
| `param1`  | `type` | `default` | Description of the parameter. |
| `param2`  | `type` | `default` | Description of the parameter. |

## Returns

<!-- Describe the return value, including its type and structure. -->

## Usage

### Basic example

```python
from REPONAME import my_function

result = my_function(...)
```

### Example with parameters

```python
result = my_function(
    param1=value,
    param2=value,
)
```

## Workflow

<!-- Describe the recommended workflow for using this method. -->

1. Prepare the input data.
2. Configure the relevant parameters.
3. Call the method.
4. Inspect or process the result.

## Important parameters

<!-- Explain the parameters that have the greatest impact on behavior or results. -->

### `param1`

<!-- Explain when to change this parameter and how it affects the result. -->

### `param2`

<!-- Explain when to change this parameter and how it affects the result. -->

## Output

<!-- Explain the structure and interpretation of the output. -->

```python
# Example of inspecting the result
print(result)
```

## Common use cases

<!-- List the most common situations where this method should be used. -->

* Use case 1
* Use case 2
* Use case 3

## Best practices

<!-- Document recommended usage, parameter choices, and important considerations. -->

*
*
*

## Common pitfalls

<!-- Document mistakes users commonly make when using this method. -->

*
*
*

## Related methods

<!-- Link or refer to related methods that may be useful. -->

* `REPONAME.related_function()`
* `REPONAME.other_function()`

## Troubleshooting

<!-- Add method-specific troubleshooting information. -->

### Error or unexpected behavior

**Cause:** <!-- Explain the likely cause. -->

**Solution:** <!-- Explain how to resolve it. -->
