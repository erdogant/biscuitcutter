---
name: REPONAME
description: Use this skill when working with REPONAME, a Python library for ...
---

# REPONAME

<!--
AGENT INSTRUCTIONS

This file is a template for creating an Agent Skill for a Python library.

Complete this SKILL.md by inspecting the repository and its documentation.
Do not invent API functionality, parameters, examples, or behavior.

Before completing this file:

1. Inspect the repository structure.
2. Read the README and project documentation.
3. Inspect the public Python API.
4. Identify the main functions, classes, and methods.
5. Identify the most important workflows and use cases.
6. Inspect existing examples and tests when available.
7. Check the package dependencies and installation instructions.
8. Identify common errors, limitations, and compatibility issues.
9. Create reference files for important methods or functions.
10. Create executable examples corresponding to those references.

Replace every `REPONAME`, `...`, and placeholder comment with repository-specific
content.

Keep the skill focused on helping an AI coding agent use the library correctly.
Prefer practical instructions and executable examples over general documentation.

IMPORTANT:
- Do not document functionality that does not exist.
- Use the actual API exposed by the repository.
- Follow the coding conventions already used by the project.
- Prefer the repository's own examples and tests as the source of truth.
- Preserve important warnings, assumptions, and limitations.
- Keep examples minimal but executable.
- Ensure referenced files actually exist.
-->

## Overview

<!--
AGENT: Describe what the library does, its primary purpose, and the problems
it solves. Explain when an agent should use this skill.
-->

## When to use this skill

<!--
AGENT: List the types of user requests or development tasks for which this
skill should be activated.

Focus on practical triggers such as:
- using a specific API
- performing a specific analysis
- creating a visualization
- training a model
- processing data
- debugging the library
-->

## Core capabilities

<!--
AGENT: Identify the main capabilities of the library.

Base this on the actual repository and public API.
Group related functionality where appropriate.
-->

## Installation

<!--
AGENT: Document the recommended installation method.

Include:
- package installation command
- optional dependencies
- development installation if relevant
- important version requirements
-->

## Usage

<!--
AGENT: Provide the most important usage patterns.

Use real API calls from the repository.
Keep examples concise and executable.
-->

## API

<!--
AGENT: Summarize the important public functions, classes, and methods.

Do not reproduce the entire API reference here.
Detailed methods should have their own files under references/.
-->

## Workflows

<!--
AGENT: Describe recommended end-to-end workflows.

For each important workflow:
1. Identify the input.
2. Describe preprocessing if required.
3. Identify the main API calls.
4. Explain important parameters.
5. Describe how to interpret or use the output.
-->

## Examples

<!--
AGENT: Identify the most useful examples in the repository.

Add references to executable examples under examples/.
Each important method reference should have a corresponding example.
-->

## Best practices

<!--
AGENT: Document library-specific best practices.

Include:
- recommended parameter choices
- input requirements
- performance considerations
- reproducibility
- validation
- common usage patterns
- important assumptions or limitations
-->

## Troubleshooting

<!--
AGENT: Complete references/troubleshooting.md with common installation,
API, data, dependency, performance, and runtime problems.

Do not duplicate detailed troubleshooting here.
-->

* troubleshooting: `references/troubleshooting.md`

## References

<!--
AGENT: Create a reference file for each important method or function.

Each reference should:
- explain what the method does
- document its signature and parameters
- explain the return value
- provide a minimal usage example
- describe important parameters
- document common pitfalls
- link to the corresponding executable example

Replace the placeholders below with actual methods.
-->

For detailed information about individual methods and functions:

* method_A: `references/method_A.md`

Examples:

* `examples/method_A.py`
