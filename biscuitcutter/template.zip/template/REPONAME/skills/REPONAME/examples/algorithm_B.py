"""
Discrete Bayesian Network Example
=================================

This example demonstrates the complete workflow for learning and using
a discrete Bayesian Network with REPONAME.

Workflow
--------
1. Load a discrete example dataset.
2. Learn the Bayesian Network structure.
3. Learn the parameters (CPDs).
4. Inspect the learned network.
5. Perform probabilistic inference.
6. Generate synthetic data.

"""

# %% Libraries
import REPONAME as bn


# %% Load example dataset
df = bn.import_example('sprinkler')

print('\n[REPONAME] > Example data:')
print(df.head())

print('\n[REPONAME] > Data types:')
print(df.dtypes)


# %% Structure learning
# Learn the DAG from the discrete observations.
#
# Hill Climbing with BIC is a standard score-based approach for
# discrete Bayesian Networks.

DAG = bn.structure_learning.fit(
    df,
    methodtype='hc',
    scoretype='bic',
    verbose=3,
)

print('\n[REPONAME] > Learned DAG:')
print(DAG['model_edges'])


# %% Plot learned structure
bn.plot(DAG)

# %% Plot learned structure using graphviz
bn.plot_graphviz(DAG)


# %% Parameter learning
# Learn the Conditional Probability Distributions (CPDs)
# for all variables in the DAG.

model = bn.parameter_learning.fit(
    DAG,
    df,
    methodtype='bayes',
    verbose=3,
)

print('\n[REPONAME] > Bayesian Network:')
print(model['model'])


# %% Inspect CPDs
# Each node in a discrete Bayesian Network has a Conditional
# Probability Distribution.

print('\n[REPONAME] > Learned CPDs:')
for cpd in model['model'].get_cpds():
    print(cpd)


# %% Plot Bayesian Network
bn.plot(model)
# or
bn.plot_graphviz(DAG)


# %% Exact inference
# Calculate:
#
#     P(Wet_Grass | Rain=1, Sprinkler=0)
#
# The result contains the probability distribution over Wet_Grass.

query = bn.inference.fit(
    model,
    variables=['Wet_Grass'],
    evidence={
        'Rain': 1,
        'Sprinkler': 0,
    },
    verbose=3,
)

print('\n[REPONAME] > Inference result:')
print(query)

print('\n[REPONAME] > Inference DataFrame:')
print(query.df)


# %% Joint inference
# Query multiple variables simultaneously.

query_joint = bn.inference.fit(
    model,
    variables=['Wet_Grass', 'Rain'],
    evidence={
        'Sprinkler': 1,
    },
    verbose=3,
)

print('\n[REPONAME] > Joint inference:')
print(query_joint.df)


# %% Conditional sampling
# Generate synthetic observations from the learned Bayesian Network.
#
# Without evidence, sampling generates observations from the complete
# joint distribution.

samples = bn.sampling(
    model,
    n=1000,
    methodtype='bayes',
    verbose=3,
)

print('\n[REPONAME] > Synthetic samples:')
print(samples.head())

print('\n[REPONAME] > Sample shape:')
print(samples.shape)


# %% Sampling conditioned on evidence
# Generate observations conditioned on:
#
#     Rain=1
#     Cloudy=0
#
# For Bayesian sampling, evidence uses rejection sampling.

conditional_samples = bn.sampling(
    model,
    n=100,
    methodtype='bayes',
    evidence={
        'Rain': 1,
        'Cloudy': 0,
    },
    verbose=3,
)

print('\n[REPONAME] > Conditional synthetic samples:')
print(conditional_samples.head())


# %% Gibbs sampling
# Gibbs sampling generates observations from the learned Bayesian Network.
#
# The current REPONAME sampling implementation does not support evidence
# with Gibbs sampling.

gibbs_samples = bn.sampling(
    model,
    n=100,
    methodtype='gibbs',
    verbose=3,
)

print('\n[REPONAME] > Gibbs samples:')
print(gibbs_samples.head())


# %% Summary
print('\n' + '=' * 70)
print('Discrete Bayesian Network example completed successfully.')
print('=' * 70)

print('\nNodes:')
print(list(model['model'].nodes()))

print('\nEdges:')
print(list(model['model'].edges()))

print('\nNumber of CPDs:')
print(len(model['model'].get_cpds()))

print('\nSynthetic data:')
print(samples.shape)

print('\nConditional synthetic data:')
print(conditional_samples.shape)

print('\nGibbs samples:')
print(gibbs_samples.shape)
