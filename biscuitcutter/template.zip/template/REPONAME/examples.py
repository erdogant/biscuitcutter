# %%
import REPONAME
print(dir(REPONAME))
print(REPONAME.__version__)

# %%
from REPONAME import REPONAME
model = REPONAME()
model.plot()

# %%
