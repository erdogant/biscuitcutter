"""Utils.

Name        : REPONAME.py
Author      : AUTHORNAME
Contact     : CONTACTADRESS
github      : https://github.com/GITHUBNAME/REPONAME
Licence     : See licences

"""
import numpy as np
from tqdm import tqdm
import datazets as dz

import logging
logger = logging.getLogger(__name__)
# if not logger.hasHandlers(): logging.basicConfig(level=logging.INFO, format='[{asctime}] [{name}] [{levelname}] {message}', style='{', datefmt='%d-%m-%Y %H:%M:%S')

# %%
def my_new_function():
    logger.info('Run utils functions!')
