import logging

# from datazets import get as import_example

from REPONAME.REPONAME import REPONAME

# from REPONAME.REPONAME import (
    # import_example,
    # )


__author__ = 'AUTHORNAME'
__email__ = 'CONTACTADRESS'
__version__ = '0.1.0'

# Setup package-level logger
_logger = logging.getLogger('REPONAME')
_log_handler = logging.StreamHandler()
_formatter = logging.Formatter(fmt='[{asctime}] [{name:<12.12}] [{levelname:<8}] {message}', style='{', datefmt='%d-%m-%Y %H:%M:%S')
_log_handler.setFormatter(_formatter)
_log_handler.setLevel(logging.DEBUG)
if not _logger.hasHandlers():  # avoid duplicate handlers if re-imported
    _logger.addHandler(_log_handler)
_logger.setLevel(logging.DEBUG)
_logger.propagate = True  # allow submodules to inherit this handler



# module level doc-string
__doc__ = """
REPONAME
=====================================================================

REPONAME is for...

Example
-------
>>> from REPONAME import REPONAME
>>> model = REPONAME()
>>> REPONAME.plot()

References
----------
https://github.com/GITHUBNAME/REPONAME

"""
