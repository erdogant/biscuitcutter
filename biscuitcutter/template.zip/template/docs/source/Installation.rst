Installation Examples
#####################

Recommende is to install ``REPONAME`` from an isolated Python environment using conda or Pyenv:

Create Conda Environment
**************************

.. code-block:: console

    conda create -n env_REPONAME python=3.12
    conda activate env_REPONAME


Create Pyenv Environment
**************************

.. code-block:: console

    # Create a new project directory
    mkdir my_REPONAME_project
    cd my_REPONAME_project

    # Create virtual environment
    python -m venv venv

    # Activate it
    # On macOS/Linux:
    source venv/bin/activate

    # On Windows:
    venv\Scripts\activate

    # Install memvid
    pip install REPONAME


Pypi
**********************

.. code-block:: console

    # Install from Pypi:
    pip install REPONAME

    # Force update to latest version
    pip install -U REPONAME


Github Source
************************************

.. code-block:: console

    # Install directly from github
    pip install git+https://github.com/GITHUBNAME/REPONAME


Uninstalling
################

Remove environment
**********************

.. code-block:: console

   # List all the active environments. REPONAME should be listed.
   conda env list

   # Remove the REPONAME environment
   conda env remove --name REPONAME

   # List all the active environments. REPONAME should be absent.
   conda env list


Remove installation
**********************

Note that the removal of the environment will also remove the ``REPONAME`` installation.

.. code-block:: console

    # Install from Pypi:
    pip uninstall REPONAME
