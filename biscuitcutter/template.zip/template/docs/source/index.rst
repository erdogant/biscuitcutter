REPONAME's documentation!
==========================

|python| |pypi| |docs| |stars| |LOC| |downloads_month| |downloads_total| |license| |forks| |open issues| |project status| |medium| |colab| |DOI| |repo-size| |donate|

-----------------------------------

.. |logo| image:: ../figs/logo.png
   :width: 125px
   :height: 125px

.. container:: logo-description

   .. image:: ../figs/logo.png
      :width: 125px
      :height: 125px
      :align: left
      :alt: REPONAME logo

   *REPONAME* is a comprehensive Python library for ...


   .. raw:: html

      <div style="clear: both;"></div>

-----------------------------------

**Key Features:**
    - **Multiple Detection Methods**: Topology (persistent homology)
    - **1D and 2D Support**: Works with time series, signals, images, and spatial data
    - **Advanced Preprocessing**: Denoising, scaling, interpolation, and image preprocessing

The library includes comprehensive preprocessing capabilities (denoising, normalizing, resizing) and advanced visualization tools (3D mesh plots, persistence diagrams, preprocessing pipelines) to help users understand and analyze their data effectively.

-----------------------------------

Support
-----------

.. raw:: html

    <div style="display: flex; align-items: center; gap: 20px;">
        <iframe
            srcdoc='<a href="https://www.buymeacoffee.com/GITHUBNAME" target="_blank"><img src="https://img.buymeacoffee.com/button-api/?text=Buy me a coffee&amp;emoji=&amp;slug=GITHUBNAME&amp;button_colour=FFDD00&amp;font_colour=000000&amp;font_family=Cookie&amp;outline_colour=000000&amp;coffee_colour=ffffff" /></a>'
            style="border:none; width:250px; height:80px; flex-shrink: 0;">
        </iframe>
        <div>
            <p><strong>Yes! This library is entirely free but it runs on coffee. </strong>Your ❤️ is important to keep maintaining this package. You can <a href="https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html">support</a> in various ways, have a look at the <a href="https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html">sponsor page</a>.</p>
        </div>
    </div>

-----------------------------------

.. tip::
	`Medium Blog: A Step-by-Step Guide To Accurately Detect Peaks and Valleys. <https://GITHUBNAME.medium.com>`_


Installation
-------------

.. code-block:: console

    pip install REPONAME

-----------------------------------


Content
=======

.. toctree::
   :maxdepth: 1
   :caption: Background

   Abstract


.. toctree::
   :maxdepth: 1
   :caption: Installation

   Installation


.. toctree::
  :maxdepth: 1
  :caption: Methods

  Save and Load


.. toctree::
  :maxdepth: 1
  :caption: Examples

  Examples


.. toctree::
  :maxdepth: 1
  :caption: Documentation

  Documentation
  Coding quality
  REPONAME.REPONAME



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`



.. |python| image:: https://img.shields.io/pypi/pyversions/REPONAME.svg
    :alt: |Python
    :target: https://GITHUBNAME.github.io/REPONAME/

.. |pypi| image:: https://img.shields.io/pypi/v/REPONAME.svg
    :alt: |Python Version
    :target: https://pypi.org/project/REPONAME/

.. |docs| image:: https://img.shields.io/badge/Sphinx-Docs-blue.svg
    :alt: Sphinx documentation
    :target: https://GITHUBNAME.github.io/REPONAME/

.. |stars| image:: https://img.shields.io/github/stars/GITHUBNAME/REPONAME
    :alt: Stars
    :target: https://img.shields.io/github/stars/GITHUBNAME/REPONAME

.. |LOC| image:: https://sloc.xyz/github/GITHUBNAME/REPONAME/?category=code
    :alt: lines of code
    :target: https://github.com/GITHUBNAME/REPONAME

.. |downloads_month| image:: https://static.pepy.tech/personalized-badge/REPONAME?period=month&units=international_system&left_color=grey&right_color=brightgreen&left_text=PyPI%20downloads/month
    :alt: Downloads per month
    :target: https://pepy.tech/project/REPONAME

.. |downloads_total| image:: https://static.pepy.tech/personalized-badge/REPONAME?period=total&units=international_system&left_color=grey&right_color=brightgreen&left_text=Downloads
    :alt: Downloads in total
    :target: https://pepy.tech/project/REPONAME

.. |license| image:: https://img.shields.io/badge/license-MIT-green.svg
    :alt: License
    :target: https://github.com/GITHUBNAME/REPONAME/blob/master/LICENSE

.. |forks| image:: https://img.shields.io/github/forks/GITHUBNAME/REPONAME.svg
    :alt: Github Forks
    :target: https://github.com/GITHUBNAME/REPONAME/network

.. |open issues| image:: https://img.shields.io/github/issues/GITHUBNAME/REPONAME.svg
    :alt: Open Issues
    :target: https://github.com/GITHUBNAME/REPONAME/issues

.. |project status| image:: http://www.repostatus.org/badges/latest/active.svg
    :alt: Project Status
    :target: http://www.repostatus.org/#active

.. |medium| image:: https://img.shields.io/badge/Medium-Blog-green.svg
    :alt: Medium Blog
    :target: https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html#medium-blog

.. |donate| image:: https://img.shields.io/badge/Support%20this%20project-grey.svg?logo=github%20sponsors
    :alt: donate
    :target: https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html#

.. |colab| image:: https://colab.research.google.com/assets/colab-badge.svg
    :alt: Colab example
    :target: https://GITHUBNAME.github.io/REPONAME/pages/html/Documentation.html#colab-notebook

.. |DOI| image:: https://zenodo.org/badge/246504758.svg
    :alt: Cite
    :target: https://zenodo.org/badge/latestdoi/246504758

.. |repo-size| image:: https://img.shields.io/github/repo-size/GITHUBNAME/REPONAME
    :alt: repo-size
    :target: https://img.shields.io/github/repo-size/GITHUBNAME/REPONAME

.. include:: add_bottom.add
