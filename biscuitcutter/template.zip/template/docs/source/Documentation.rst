Sponsor
############

.. include:: sponsor.rst


Medium Blog
############

.. note::
	`Medium Blog: Coming soon (Wishfull thinking) <https://towardsdatascience.com/creating-beautiful-stand-alone-interactive-d3-charts-with-python-804117cb95a7>`_

Github
############

.. note::
	`Source code of REPONAME can be found at Github <https://github.com/GITHUBNAME/REPONAME/>`_


Colab Notebook
################

.. note::
	Experiment with ``REPONAME`` library using the `Colab notebook`_.

.. _Colab notebook: https://colab.research.google.com/github/GITHUBNAME/pca/blob/master/notebooks/REPONAME_notebook.ipynb


Citing
#########

.. note::
	Bibtex can be found at the right side at the `github page <https://github.com/GITHUBNAME/REPONAME/>`_.

