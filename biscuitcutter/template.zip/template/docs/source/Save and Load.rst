
Save and Load
''''''''''''''

Saving and loading models is desired as the learning proces of a model for ``REPONAME`` can take up to hours.
In order to accomplish this, we created two functions: function :func:`REPONAME.save` and function :func:`REPONAME.load`
Below we illustrate how to save and load models.


Saving
----------------

Saving a learned model can be done using the function :func:`REPONAME.save`:

.. code:: python

    import REPONAME

    # Load example data
    X,y_true = REPONAME.load_example()

    # Learn model
    model = REPONAME.fit_transform(X, y_true, pos_label='bad')

    Save model
    status = REPONAME.save(model, 'learned_model_v1')



Loading
----------------------

Loading a learned model can be done using the function :func:`REPONAME.load`:

.. code:: python

    import REPONAME

    # Load model
    model = REPONAME.load(model, 'learned_model_v1')

